#include<stdio.h>
int arr[6];
int front= -1;
int rear= -1;
void enqueue (int item, int n)
{
    if(rear == -1)
    {
        rear++;
        front++;
        arr[rear]=item;
        return;
    }
    if((rear==n-1 && front==0) ||((rear+1)==front))
    {
        printf("queue is full !\n");
        return;
    }
    if (rear == n-1)
    {
        rear = 0;
        arr[rear] = item;
        return;
    }
    rear++;
    arr[rear]=item;
    return;
}
int dequeue (int n)
{
    int result;
    if (front == -1)
    {
        printf("queue is empty !\n");
        return;
    }
    if(front == rear)
    {
        result = arr[front];
        arr[front]=NULL;
        printf("queue is empty\n");
        front = -1;
        rear = -1;
        return result;
    }
    if(front==n-1)
    {
        result = arr[front];
        arr[front]=NULL;
        front = 0;
        return result;
    }
    result=arr[front];
    arr[front]=NULL;
    front++;
    return result;
}
void print_array(int n)
{
    for(int c=0;c<n;c++)
        printf("%d",arr[c]);
    printf("\n");
}
int main()
{
    int c,n,item,result;
    n=5;
    printf("0 to 1 enqueue,2 to dequeue,3 to exit\n");
    while(1)
    {
        scanf("%d",&c);
        if(c==1)
        {
            printf("Enter item to enqueue:");
            scanf("%d",&item);
            enqueue(item,n);
            print_array(n);
        }
        else if(c==2)
        {
            result=dequeue(n);
            printf("result=%d\n",result);
            print_array(n);
        }
        else if(c==3)
        {
            printf("quitting program\n");
            break;

        }
        else
        {
            printf("wrong option.try again.\n");
            continue;
        }


    }
}



