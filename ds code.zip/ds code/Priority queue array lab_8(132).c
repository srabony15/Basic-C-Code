#include<stdio.h>
typedef struct{
        int data;
        int priority;
}pqueue;
pqueue pq [100];
int front = -1;
int rear = -1;
pqueue Dqueue (){
       pqueue temp= pq [front];
       front ++;
       return temp;
}
void Enqueue (pqueue value){
    if(front == -1){
    front=rear=0;
    pq[0]=value;
    return;
    }
    int i;
    for(i=rear;i>=front;i--){
        if(pq[i].priority<=value.priority){
            pq[i+1]=value;
            rear++;
            return;
        }
        else
            pq[i+1]=pq[i];

    }
    pq[front]=value;
    rear++;
}
void printArray()
{
    for(int i=front;i<=rear;i++)
        printf("%d",pq[i].data);
        printf("\n");
}
int main()
{
    int i;
    pqueue value;
    printf("Enqueue(1) or Dequeue(2):");
    while (scanf("%d",&i)==1){
        if(i==1){
            printf("Enqueue Enter a number:");
            scanf("%d %d",&value.data,&value.priority);
            Enqueue(value);
            printArray();
        }
else if(i==2){
    if(front != -1){
        pqueue num = Dqueue();
        printf("Deleted item: %d\n",num.data);
    }
    else
        printf("Queue is empty\n");
    printArray();
}
printf("Enqueue (1) or Dequeue (2):");

    }
}


