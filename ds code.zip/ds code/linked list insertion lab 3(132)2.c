#include<stdio.h>
#include<stdlib.h>
#include<string.h>
typedef struct n_node{
int data;
struct n_node *next;
}node;

node *start=NULL;
void print_linked_list(node *temp)
{
    while(temp != NULL)
    {
        printf("%d",temp->data);
        temp=temp->next;

    }
    printf("\n");
}
void add_to_start(int item)
{
    node *temp=(node*)malloc(sizeof(node));
    temp->data=item;
    if(start==NULL)
    {
        start=temp;
        temp->next=NULL;
    }
    else
    {
        temp->next=start;
        start=temp;
    }
}
int add_to_mid(int item)
{
    int test;
    node *move=start;
    node *temp=(node*)malloc(sizeof(node));
    temp->data=item;
    printf("Enter which item to put new data after:");
    scanf("%d",&test);
    while(move != NULL)
    {
        if((move->data)==test)
        {
            temp->next=move->next;
            move->next=temp;
            return 1;
        }
        move=move->next;
    }
    return 0;
}
void add_to_end(int item)
{
    node *move=start;
    node *temp=(node*)malloc(sizeof(node));
    temp->data=item;
    while(1)
    {
        if(move->next==NULL)
        {
            move->next=temp;
            temp->next=NULL;
            break;
        }
        move=move->next;
    }
}
void remove_item(node*move)
{
    int item;
    node *move1;
    printf("\nEnter data item to remove from list:");
    scanf("%d",&item);
    while(move->data!=item)
    {
        move1=move;
        move=move->next;
    }
    move1->next=move->next;
}
int main()
{
    int tag=0,n,c,item,test;
    printf("Number of items to insert:");
    scanf("%d",&n);
    for(int c=1;c<=n;c++)
    {
        printf("Enter data %d:",c);
        scanf("%d",&item);
        printf("where to insert?(press 1,2,or 3)");
        scanf("%d",&test);
        if(test==1)
        {
            add_to_start(item);
            printf("New List:");
        print_linked_list(start);

        }


    else if(test==2)
    {
        add_to_end(item);
        printf("New List:");
        print_linked_list(start);
    }

else if(test==3)
{
    tag=add_to_mid(item);
    if(tag==0)
    {
        printf("item not found");
    }
    else
    {
        printf("new list:");
        print_linked_list(start);
    }
}
printf("\n\n");
}
return 0;
}


