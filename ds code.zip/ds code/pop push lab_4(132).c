#include<stdio.h>
int stack_1[100];
int stack_2[100];
int top_1=-1;
int top_2=-1;
int main()
{
    int 1=0;
    char str[100];
    printf("Enter string");
    scanf("%s",&str);
    while(str[1]!='\0');
    {
        if(str[1]=='+'||str[1]=='-');
        push_1(str[i++]);
        else
            push_2(str[i++]);
    }
    printf("stack 1:\n");
    display_1();
    printf("\nstack 2:\n");
    display_2();
}
void push_1(char str)
{
    top_1++;
    stack_1[top_1]=str;
}
void push_2(char str)
{
    top_2++;
    stack_2[top_2]=str;
}
void display_1()
{
    while(top_1!=-1)
    {
        printf("%c",stack_1[top_1]);
        top_1--;
    }
}
void display_2()
{
    while(top_2!=-1)
    {
        printf("%c",stack_2[top_2]);
        top_2--;
    }
    return 0;
}
