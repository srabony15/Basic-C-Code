#include<stdio.h>
#define sz 10
void init (int mat[][sz],int v)
{
    int i,j;
    for (i=0; i<v; i++)
        for (j=0;j<v;j++)
        mat[i][j]=0;
}
void printadjmatrix(int mat[][sz],int v)
{
    int i,j;
    printf("\nadjacency metrix:\n");
    for(i=0; i<v; i++)
    {
        for(j=0;j<v;j++)
        {
            printf("%d",mat[i][j]);
        }
        printf("\n");
    }
}
int main()
{
    int i,j,ver,edg,st,en,indeg[sz]={0},outdeg[sz]={0};
    int adjmat[sz][sz];
    printf("Enter number of vertex:");
    scanf("%d",&ver);
    printf("Enter number of edges:");
    scanf("%d",&edg);

    //init(adjmat,ver);
    for(i=0;i<ver;i++)
    {
        for(int j=0;j<ver;j++)
            adjmat[i][j]=0;
    }
    printf("Enter start and end of each edge:\n");
    for(i=0;i<edg;i++)
    {
        printf("edge %d:",i+1);
        scanf("%d %d",&st,&en);
        adjmat[st-1][en-1]=1;
	adjmat[en-1][st-1]=1;
        outdeg[st]++;
        indeg[en]++;

    }
     //printadjmat(adjmat, ver);

    printf("\nindeg: \n");

    for(i=0; i<ver; i++)
    {
        for(j=0; j<ver; j++)
            printf("%d: %d \n", i, indeg[i]);
    }

    printf("\noutdeg: \n");

    for(i=0; i<ver; i++)
    {
        for(j=0; j<ver; j++)
            printf("%d: %d \n", j, outdeg[j]);
    }

    printf("\n");
    printadjmatrix(adjmat,ver);
    return 0;
}
