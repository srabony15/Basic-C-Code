#include<stdio.h>
#include<stdlib.h>
struct node
{
int data_element;
struct node *next;
};
void display(struct node *n)
{
while (n != NULL)
{
printf("%d\n", n->data_element);
n = n->next;
}
}
int main()
{
printf("Enter the list!\n\n");

struct node *first = NULL;
struct node *second = NULL;
struct node *third = NULL;

first = (struct node*)malloc(sizeof(struct node));
second = (struct node*)malloc(sizeof(struct node));
third = (struct node*)malloc(sizeof(struct node));
first->data_element = 100;
first->next = second;
second->data_element =200, 500;
second->next = third;
third->data_element =500,200,100;
third->next = NULL;
display(first);
return 0;
}
