#include <stdio.h>

typedef struct n_node{
    int data;
    struct n_node *next;
}node;

node *start = NULL;
node *tail = NULL;

void enqueue (int item)
{
    node *temp = (node*)malloc(sizeof(node));

    if (start == NULL)
    {
        start = temp;
        temp->data = item;
        temp->next = NULL;
        tail = start;
        return;
    }

    tail->next = temp;
    temp->data = item;
    temp->next = NULL;
    tail = temp;
    return;
}

int dequeue ()
{
    int result;
    if (start == NULL)
    {
        printf("Queue is already empty\n");
        return;
    }

    result = start->data;
    start = start->next;
    return result;
}

void print_queue ()
{
    node* temp = start;

    while (temp != NULL){
        printf("%d ", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

int main()
{
    int test, item, result;

    printf("Type 1 to enqueue. 2 to dequeue. 3 to exit\n");

    while (1)
    {
        scanf("%d", &test);

        if (test == 1)
        {
            printf("Enter item: ");
            scanf("%d", &item);
            enqueue (item);
            print_queue ();
        }

        else if (test == 2)
        {
            result = dequeue();
            printf("Item dequeued is %d\n", result);
            print_queue ();
        }

        else if (test == 3)
            break;
    }

    return 0;
}

