#include<stdio.h>
#define sz 100
int adjMat[sz][sz],status[sz]={1},queue[sz];
int ver;
int front=-1;
int rear = -1;

int  isEmpty()
{
    if(front== -1)
        return 1;
    else return 0;
}
void Enqueue(int node)
{
    if(front== -1)
    {
        front = 0;
    }
    rear += 1;
    queue [rear]= node;
}
int Dqueue()
{
    if(front== -1)
        return -1;
    int temp = queue[front];
    if(front == rear)
        front = rear = -1;
    else front += 1;
    status[temp]=3;
    return temp;
}
void BFS (int st)
{
    Enqueue(st);
    status[st]=2;
    while(!isEmpty())
    {
        int node=Dqueue();
        status[node]=3;
        printf("-----%d",node +1);
        for(int i=0;i<ver;i++)
        {
            if((adjMat[node][i]==1)&&(status[i]==1))
            {
                status[i]=2;
                Enqueue(i);
            }
        }
        printf("\n");
    }
}
/*4
5
1 2
1 3
2 3
3 4
4 1*/

void init()
{
    int i,j;
    for(i=0;i<ver;i++)
        status[i]=1;
        for(j=0;j<ver;j++)
        adjMat[i][j]=0;
}
void printAdjMatrix(int mat[][sz],int v)
{
    int i,j;
    printf("\n Adjacency Matrix: \n");
    for(i=0;i<v;i++)
    {
        for(j=0;j<v;j++)
        {
            printf("%d", mat[i][j]);
        }
        printf("\n");
    }
}
int main()
{
    int i,edg,st,en;
    printf("Enter number of vertex:");
    scanf("%d", &ver);
    printf("Enter number of edges:");
    scanf("%d",&edg);

    init();
    printf("Enter start and end of each edge:\n");
    for(i=0;i<edg;i++)
    {
        printf("Edge %d:",i+1);
        scanf("%d %d",&st, &en);
        adjMat[st-1][en-1]=1;
    }
    printAdjMatrix(adjMat,ver);

    printf("Enter start node for BFS:");
    scanf("%d",&st);

    BFS(st -1);

    return 0;
}


