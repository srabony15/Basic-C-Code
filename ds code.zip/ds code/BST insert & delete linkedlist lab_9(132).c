#include<stdio.h>
#include<stdlib.h>
struct node
{
    int data;
    struct node *left;
    struct node *right;
};
struct node* newnodee =NULL;
struct node* creatNode(int data)
{
    struct node *temp = (struct node*)malloc(sizeof(struct node));
    temp->data=data;
    temp->left=NULL;
    temp->right=NULL;
    return temp;
}
struct node* BSTinsert(struct node *root, int data)
{
    if(root == NULL)
        return creatNode(data);
    if(data< root->data)
        root->left = BSTinsert(root->left,data);
    else
        root->right=BSTinsert(root->right,data);
    return root;
}
struct node* inorderSuccessor(struct node *node)
{
    struct node *temp=node;
    while (temp->left != NULL)
        temp = temp->left;
    return temp;
}
struct node *BSTdelete(struct node *root, int data)
{
    if(root == NULL)
        return root;
    if(data<root->data)
        root->left= BSTdelete(root->left, data);
    else if(data>root->data)
        root->right=BSTdelete(root->right, data);
    else
    {
        if(root->left==NULL)
        {
            struct node *temp=root->right;
            free (root);
            return temp;
        }
        else if(root->right == NULL)
        {
            struct node *temp=root->left;
            free(root);
            return temp;
        }
        struct node *temp=inorderSuccessor(root->right);
        root->data = temp->data;
        root->right=BSTdelete(root->right, temp->data);
    }
    return root;
}
void preorderTraversal(struct node* root)
{
    if(root == NULL)
        return;
    printf("%d->", root->data);
    preorderTraversal(root->left);
    preorderTraversal(root->right);
}
void inorderTraversal(struct node *root)
{
    if(root == NULL)
        return;
    inorderTraversal(root->left);
    printf("-> %d", root->data);
    inorderTraversal(root->right);
}
void postorderTraversal(struct node* root)
{
    if(root == NULL)
        return;
    postorderTraversal(root->left);
    postorderTraversal(root->right);
    printf("%d->", root->data);
}
int main()
{
    int i, num;
    struct node *root = NULL;
    printf("Binary search Tree\n\n");
    printf("Press 1(Insert) or 2(Delete)");

    while(scanf("%d",&i)== 1)
    {
        if(i == 1)
        {
            printf("(Insert) Enter data:");
            scanf("%d", &num );
            root = BSTinsert(root,num);
            inorderTraversal(root);
        }
        else if (i == 2)
        {
            printf("(Delete)Enter data to delete:");
            scanf("%d", & num );
            root = BSTdelete(root,num);
            inorderTraversal(root);
        }
        printf("\n Enqueue (1) or Dequeue (2):");
    }
    return 0;
}
