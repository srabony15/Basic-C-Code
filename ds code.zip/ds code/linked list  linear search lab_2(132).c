#include<stdio.h>
#include<stdlib.h>
struct Node
{
    int data;
    struct Node *next;
};
struct Node *head=NULL;
void search(struct Node *head, int num)
{
    while(head !=NULL)
    {
        if(head -> data==num)
        {
            printf("%d is found in list.\n",head->data);
            return;
        }
        head = head -> next;
    }
    printf("search item not found.\n");
    return;
}
int main()
{
    int i,n,num;
    struct Node *Newnode = NULL;
    printf("Enter 4 number:");
    for(i=0;i<4;i++)
    {
        scanf("%d",&n);
        Newnode=(struct Node*)malloc(sizeof(struct Node));
        Newnode -> data = n;
        Newnode -> next = head;
        head = Newnode;
    }
    printf("Enter search item:");
    scanf("%d",&num);
    search(head,num);
    return 0;
}
