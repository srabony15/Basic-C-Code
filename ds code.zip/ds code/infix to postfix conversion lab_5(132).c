#include<stdio.h>
#include<string.h>

char stack[100];
int top = -1;

void push(char item) {
   stack[++top] = item;
}

char pop() {
   return stack[top--];
}

int precedence(char symbol) {

   switch(symbol) {
      case '^':
         return 4;
         break;
      case '*':
      case '/':
         return 3;
         break;
      case '+':
      case '-':
         return 2;
         break;
      case '(':
      case ')':
         return 1;
         break;
   }
}

int isOperand(char ch) {

   switch(ch) {
      case '+':
      case '-':
      case '*':
      case '/':
      case '^':
      case '(':
      case ')':
         return 0;
         break;
      default:
         return 1;
   }
}

void infix_to_postfix(char infix[],char postfix[]) {
   int i,k;
   char ch;
   stack[++top] = '(';

   k = 0;
   for(i=0; i<strlen(infix); i++) {
      ch = infix[i];

      if(isOperand(ch)) {
         postfix[k] = ch;
         k++;
      }
      else if(ch == '(') {
         push(ch);
      }
      else if(ch == ')') {
         while(stack[top] != '(') {
            postfix[k] = pop();
            k++;
         }

         pop();
      }
      else if(precedence(ch)>precedence(stack[top])) {
         push(ch);
      }
      else{
         while(precedence(ch)<=precedence(stack[top])) {
             postfix[k] = pop();
             k++;
         }

         push(ch);
      }
   }

   while(stack[top] != '(') {
      postfix[k] = pop();
      k++;
   }

   postfix[k]='\0';

}


void main() {
   char infix[100], postfix[100];
   printf("Enter an expression (infix): ");
   gets(infix);  // (4+(2*3))/5

   infix_to_postfix(infix,postfix);

   printf("Postfix expression: %s\n" , postfix);
}
